# Codigo para correr en la terminal desde
#Scrapy shell
'''fetch("https://doi.org/10.1371/journal.pone.0005738")
import html2text
converter = html2text.HTML2Text()
converter.ignore_links=True
converter.ignore_images=True
converter.ignore_tables=True
texto = converter.handle(response.css('*').get())
f = open('paper1.txt', 'w')
f.write(texto)
f.close()'''

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from wordcloud import WordCloud

# 4.
def separar_texto(pals):
    '''Given a string (pals), returns a list with every word made only of
    letters, ignoring numbers and other symbols that may be in the original
    string.'''
    solo_texto = []
    i = 0
    palabra = str()
    while i < len(pals):
        if pals[i].isalpha():
            palabra += pals[i]
        elif (not pals[i].isalpha()) and len(palabra) != 0:
            solo_texto.append(palabra)
            palabra = str()
        i += 1
    if len(palabra) != 0:
        solo_texto.append(palabra)
    return solo_texto

# 5.
def generar_dic(pals_sep):
    '''Given a list (pals_sep) composed of strings only, returns a dictionary
    with every unique string in the list as a key and the number of times that
    string appears in the list as it's value. Note that all the keys will be
    capitalized.'''
    counted = dict()
    for i in pals_sep:
        if i.capitalize() in counted.keys():
            counted[i.capitalize()] += 1
        else:
            counted[i.capitalize()] = 1
    return counted

# 6.
def word_histogram(freq_pals, log=True, title=''):
    '''Given a dictionary (freq_pals), with numbers as values, will plot and
    show a histogram with this data. The "log" keyword argument can be set to
    False in order have a linear scale on the axis of the plot.'''
    with sns.axes_style('ticks', {'axes.grid': True}):
        sns.distplot(list(freq_pals.values()), kde=False)
        if log:
            plt.yscale('log')
        if title != '':
            plt.title(label=title, fontsize=17)
        plt.show()
    return

# 7.
def generar_wordcloud(freq_pals, width=480, height=480, margin=0):
    '''Given a dictionary (freq_pals), with numbers as values and strings as
    keys, generates and shows a fancy wordcloud in which the sizes of the words
    represent the value in the dictionary associated to the string key.'''
    wordcloud = WordCloud(width=width, height=height, margin=margin)
    wordcloud.generate_from_frequencies(freq_pals)
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")
    plt.margins(x=0, y=0)
    plt.show()
    return

# 8.
def generar_dict_filt(pals_sep, pals_filtro=set(), n=0):
    '''Given a list (pals_sep) composed of strings only, returns a dictionary
    with every unique string in the list as a key and the number of times that
    string appears in the list as it's value. This function will also exclude
    strings in pals_filtro from the final count, and if a positive value n is
    entered as a parameter, then the output dictionary will only include the n
    highest values in it. Note that all the keys will be capitalized.'''
    counted = dict()
    pals_filtro = {pal.capitalize() for pal in pals_filtro}
    for i in pals_sep:
        if i.capitalize() in pals_filtro:
            continue
        elif i.capitalize() in counted.keys():
            counted[i.capitalize()] += 1
        else:
            counted[i.capitalize()] = 1
    if n > 0:
        n_counted = pd.Series(counted).sort_values().tail(n)
        counted = dict(n_counted)
    return counted

# Extra.
def generar_filt(pals_sep, toleranceQ=8, toleranceL=2, interest=set(), exclude=set()):
    palsdic = generar_dic(pals_sep)
    interest = {pal.capitalize() for pal in interest}
    exclude = {pal.capitalize() for pal in exclude}
    df = pd.DataFrame(data=palsdic.values(), columns=['count'], index=palsdic.keys())
    df['len'] = [len(pal) for pal in palsdic.keys()]
    filtroQ = df['count'] > toleranceQ*df['count'].std()
    filtroL = df['len'] <= toleranceL
    filtro = set(df[filtroQ | filtroL].index)
    filtro = filtro - interest
    filtro = filtro|exclude
    return filtro


'''
paper1 = open('paper1.txt', 'r')
texto = paper1.read()

listapals = separar_texto(texto)  # 4.

palscont = generar_dic(listapals)  # 5.

word_histogram(palscont)  # 6.

generar_wordcloud(palscont)  # 7.

pals_filtro = {'A', 'To', 'In', 'And', 'Of', 'The'}  # 8.
palscontfilt = generar_dict_filt(listapals, pals_filtro)
word_histogram(palscontfilt)
generar_wordcloud(palscontfilt)
# Extra.
pals_filtro = generar_filt(listapals)
palscontfilt = generar_dict_filt(listapals, pals_filtro)
word_histogram(palscontfilt)
generar_wordcloud(palscontfilt)
'''

stop_words = open('stop-word-list.txt', 'r') # http://xpo6.com/wp-content/uploads/2015/01/stop-word-list.txt
stop_words = set(separar_texto(stop_words.read()))

authors = {'doyle', 'christie', 'chesterton', 'sayers'}  # 9.
# The files 'author.txt' should be in the same directory as the console is running on.
for i in authors:
    file = open(i+'.txt', 'r')
    pals = file.read()
    pals_sep = separar_texto(pals)
    pals_filtro = generar_filt(pals_sep, interest=authors, exclude=stop_words)
    freq_pals = generar_dict_filt(pals_sep, pals_filtro, 20)
    word_histogram(freq_pals, title=i)
    generar_wordcloud(freq_pals)

papers = {'paper1', 'paper2', 'paper3'}  # 10.
for i in papers:
    file = open(i+'.txt', 'r')
    pals = file.read()
    pals_sep = separar_texto(pals)
    pals_filtro = generar_filt(pals_sep, exclude=stop_words)
    freq_pals = generar_dict_filt(pals_sep, pals_filtro, 20)
    word_histogram(freq_pals, title=i)
    generar_wordcloud(freq_pals)
