# -*- coding: utf-8 -*-
import scrapy
import html2text


class MessiSpider(scrapy.Spider):
	name = 'messi'
	# allowed_domains = ['prueba.com']
	start_urls = ['https://pubmed.ncbi.nlm.nih.gov/?term=baldness&filter=simsearch2.ffrft&size=10']
	paper_num = 1
	
	def parse(self, response):
		converter = html2text.HTML2Text()
		converter.ignore_links=True
		converter.ignore_images=True
		converter.ignore_tables=True
		texto = converter.handle(response.css('*').get())
		f = open('pubmed_10results.txt', 'w')
		f.write(texto)
		f.close()
		mis_links = extraer_links(texto)
		print(mis_links)
		for link in mis_links:
			yield scrapy.Request(link, callback=self.parse_paper)

	def parse_paper(self, response):
		print('PAPER NUM', self.paper_num)
		if hasattr(response, 'text'):
			converter = html2text.HTML2Text()
			converter.ignore_links=True
			converter.ignore_images=True
			converter.ignore_tables=True
			texto = converter.handle(response.css('*').get())
			f = open('paper' + str(self.paper_num) + '.txt', 'w')
			f.write(texto)
			f.close()
			self.paper_num += 1
		else:
			raise LookupError("This isn't text")
		return

def extraer_links(texto):
	'''Given a string (texto), returns a list with an url for every Digital Object Identifier in the original text.'''
	urls = []
	if 'doi:' not in texto:
		raise LookupError('No Digital Object Identifiers in this page.')
	i = 0
	while i < len(texto):
		if texto[i:i+4] == 'doi:':
			j = i + 4
			while texto[j:j+3] != '10.':
				j += 1
				if j > len(texto):
					print('broke')
					break
			k = j
			while texto[k:k+2] != '. ':
				k += 1
				if k > len(texto):
					print('broke')
					break
			doi = texto[j:k]
			if doi != str():
				urls.append('https://dx.doi.org/' + doi)
		i += 1
	if urls == []:
		raise LookupError("Couldn't find the Digital Object Identifiers in this page.")
	return urls

